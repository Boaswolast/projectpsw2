<?php 
session_start();
$id_ruangan = $_GET['id'];
if (isset($_SESSION['keranjang'][$id_ruangan])) {
	$_SESSION['keranjang'][$id_ruangan]+=1;
}
else{
	$_SESSION['keranjang'][$id_ruangan]= 1;
}
echo "<script>alert('Berhasil Memasukkan ke Cart');</script>";
echo "<script>location='cart.php';</script>";
?>