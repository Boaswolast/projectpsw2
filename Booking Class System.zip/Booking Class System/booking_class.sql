-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Bulan Mei 2022 pada 13.13
-- Versi server: 10.4.20-MariaDB
-- Versi PHP: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booking class`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nama_lengkap` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `nama_lengkap`) VALUES
(1, 'baskoroadi', '827ccb0eea8a706c4c34a16891f84e7b', 'Baskoro Adi'),
(2, 'Admin', 'e3afed0047b08059d0fada10f400c1e5', 'Admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gedung`
--

CREATE TABLE `gedung` (
  `id_gedung` int(11) NOT NULL,
  `nama_gedung` varchar(50) DEFAULT NULL,
  `alamat_gedung` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gedung`
--

INSERT INTO `gedung` (`id_gedung`, `nama_gedung`, `alamat_gedung`) VALUES
(1, 'GD5', 'Gedung Fakultas Vokasi'),
(2, 'GD7', 'Gedung Fakultas Informatika dan Teknik Elektro'),
(3, 'GD8', 'Gedung Fakultas Bioteknologi'),
(4, 'GD9', 'Gedung Fakultas Teknologi Industri\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `likes`
--

CREATE TABLE `likes` (
  `id_likes` int(11) NOT NULL,
  `id_mahasiswa` int(11) NOT NULL,
  `id_ruangan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `likes`
--

INSERT INTO `likes` (`id_likes`, `id_mahasiswa`, `id_ruangan`) VALUES
(22, 8, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id_mahasiswa` int(11) NOT NULL,
  `nim` varchar(100) DEFAULT NULL,
  `password_mahasiswa` varchar(50) DEFAULT NULL,
  `nama_mahasiswa` varchar(100) DEFAULT NULL,
  `kelas_mahasiswa` varchar(15) DEFAULT NULL,
  `prodi_mahasiswa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesanan`
--

CREATE TABLE `pemesanan` (
  `id_pemesanan` int(11) NOT NULL,
  `tanggal_pemesanan` date DEFAULT NULL,
  `jumlah_pemesanan` int(11) NOT NULL,
  `id_mahasiswa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesanan_ruangan`
--

CREATE TABLE `pemesanan_ruangan` (
  `id_pemesanan_ruangan` int(11) NOT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `id_pemesanan` int(11) DEFAULT NULL,
  `id_ruangan` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pemesanan_ruangan`
--

INSERT INTO `pemesanan_ruangan` (`id_pemesanan_ruangan`, `jumlah`, `id_pemesanan`, `id_ruangan`) VALUES
(33, 1, 28, 1),
(34, 1, 29, 3),
(35, 1, 30, 1),
(36, 1, 31, 3),
(37, 1, 32, 5),
(43, 1, 38, 1),
(44, 1, 39, 9),
(45, 1, 40, 1),
(46, 1, 41, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `ruangan`
--

CREATE TABLE `ruangan` (
  `id_ruangan` int(11) NOT NULL,
  `nama_ruangan` varchar(100) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `deskripsi_ruangan` text DEFAULT NULL,
  `likes` int(11) NOT NULL,
  `id_gedung` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ruangan`
--

INSERT INTO `ruangan` (`id_ruangan`, `nama_ruangan`, `stok`, `deskripsi_ruangan`, `likes`, `id_gedung`) VALUES
(1, 'GD511', 1, '																		Memiliki Fasilitas yang lengkap												', 3, 1),
(2, 'GD512', 1, 'Memiliki Fasilitas yang lengkap', 0, 1),
(3, 'GD513', 1, '						Memiliki Fasilitas yang lengkap				', 0, 1),
(4, 'GD514', 1, 'Memiliki Fasilitas yang lengkap', 0, 1),
(5, 'GD521', 1, '			Memiliki Fasilitas yang lengkap		', 0, 1),
(6, 'GD622', 1, 'Memiliki Fasilitas yang lengkap', 0, 1),
(7, 'GD523', 1, 'Memiliki Fasilitas yang lengkap', 0, 1),
(8, 'GD524', 1, 'Memiliki Fasilitas yang lengkap', 0, 1),
(9, 'GD711', -1, 'Memiliki Fasilitas yang lengkap', 0, 2),
(10, 'GD712', 1, 'Memiliki Fasilitas yang lengkap', 0, 2),
(11, 'GD713', 1, 'Memiliki Fasilitas yang lengkap', 0, 2),
(12, 'GD714', 1, 'Memiliki Fasilitas yang lengkap', 0, 2),
(13, 'GD721', 1, 'Memiliki Fasilitas yang lengkap', 0, 2),
(14, 'GD722', 1, 'Memiliki Fasilitas yang lengkap', 0, 2),
(15, 'GD723', 1, 'Memiliki Fasilitas yang lengkap', 0, 2),
(16, 'GD724', 1, 'Memiliki Fasilitas yang lengkap', 0, 2),
(17, 'GD811', 1, 'Memiliki Fasilitas yang lengkap', 0, 3),
(18, 'GD812', 1, 'Memiliki Fasilitas yang lengkap', 0, 3),
(19, 'GD813', 1, 'Memiliki Fasilitas yang lengkap', 0, 3),
(20, 'GD814', 1, 'Memiliki Fasilitas yang lengkap', 0, 3),
(21, 'GD821', 1, 'Memiliki Fasilitas yang lengkap', 0, 3),
(22, 'GD822', 1, 'Memiliki Fasilitas yang lengkap', 0, 3),
(23, 'GD823', 1, 'Memiliki Fasilitas yang lengkap', 0, 3),
(24, 'GD824', 1, 'Memiliki Fasilitas yang lengkap', 0, 3),
(25, 'GD911', 1, 'Memiliki Fasilitas yang lengkap', 0, 4),
(26, 'GD912', 1, 'Memiliki Fasilitas yang lengkap', 0, 4),
(27, 'GD913', 1, 'Memiliki Fasilitas yang lengkap', 0, 4),
(28, 'GD914', 1, 'Memiliki Fasilitas yang lengkap', 0, 4),
(29, 'GD911', 1, 'Memiliki Fasilitas yang lengkap', 0, 4),
(30, 'GD922', 1, 'Memiliki Fasilitas yang lengkap', 0, 4),
(31, 'GD923', 1, 'Memiliki Fasilitas yang lengkap', 0, 4),
(32, 'GD924', 1, 'Memiliki Fasilitas yang lengkap', 0, 4);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `gedung`
--
ALTER TABLE `gedung`
  ADD PRIMARY KEY (`id_gedung`);

--
-- Indeks untuk tabel `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id_likes`),
  ADD KEY `id_pelanggan` (`id_mahasiswa`),
  ADD KEY `id_produk` (`id_ruangan`);

--
-- Indeks untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id_mahasiswa`);

--
-- Indeks untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`id_pemesanan`),
  ADD KEY `id_pelanggan` (`id_mahasiswa`);

--
-- Indeks untuk tabel `pemesanan_ruangan`
--
ALTER TABLE `pemesanan_ruangan`
  ADD PRIMARY KEY (`id_pemesanan_ruangan`),
  ADD KEY `id_pembelian` (`id_pemesanan`),
  ADD KEY `id_produk` (`id_ruangan`);

--
-- Indeks untuk tabel `ruangan`
--
ALTER TABLE `ruangan`
  ADD PRIMARY KEY (`id_ruangan`),
  ADD KEY `id_warung` (`id_gedung`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `gedung`
--
ALTER TABLE `gedung`
  MODIFY `id_gedung` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `likes`
--
ALTER TABLE `likes`
  MODIFY `id_likes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id_mahasiswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `id_pemesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT untuk tabel `pemesanan_ruangan`
--
ALTER TABLE `pemesanan_ruangan`
  MODIFY `id_pemesanan_ruangan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT untuk tabel `ruangan`
--
ALTER TABLE `ruangan`
  MODIFY `id_ruangan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`id_mahasiswa`) REFERENCES `mahasiswa` (`id_mahasiswa`),
  ADD CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`id_ruangan`) REFERENCES `ruangan` (`id_ruangan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD CONSTRAINT `pemesanan_ibfk_1` FOREIGN KEY (`id_mahasiswa`) REFERENCES `mahasiswa` (`id_mahasiswa`);

--
-- Ketidakleluasaan untuk tabel `pemesanan_ruangan`
--
ALTER TABLE `pemesanan_ruangan`
  ADD CONSTRAINT `pemesanan_ruangan_ibfk_1` FOREIGN KEY (`id_pemesanan`) REFERENCES `pemesanan` (`id_pemesanan`),
  ADD CONSTRAINT `pemesanan_ruangan_ibfk_2` FOREIGN KEY (`id_ruangan`) REFERENCES `ruangan` (`id_ruangan`);

--
-- Ketidakleluasaan untuk tabel `ruangan`
--
ALTER TABLE `ruangan`
  ADD CONSTRAINT `ruangan_ibfk_1` FOREIGN KEY (`id_gedung`) REFERENCES `gedung` (`id_gedung`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
