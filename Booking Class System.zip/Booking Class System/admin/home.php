<?php 
	include 'protect.php';
?>
<h2>Selamat Datang, <b><?php echo $_SESSION['admin']['nama_lengkap']; ?></b></h2>