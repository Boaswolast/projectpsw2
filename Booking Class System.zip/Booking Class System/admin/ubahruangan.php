<?php include 'protect.php'; ?>
<h2>Ubah Ruangan</h2>
<?php 
	$query=$conn->query("SELECT * FROM ruangan WHERE id_ruangan='$_GET[id]'");
	$data=$query->fetch_assoc();
?>

<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Ruangan</label>
		<input type="text" class="form-control" name="nama" value="<?php echo $data['nama_ruangan']; ?>">
	</div>
	<div class="form-group">
		<label>Data</label>
		<input type="number" class="form-control" name="stok" value="<?php echo $data['stok']; ?>">
	</div>
	<div class="form-group">
		<label>Deskripsi</label>
		<textarea class="form-control" name="deskripsi" rows="5">
			<?php echo $data['deskripsi_ruangan']; ?>
		</textarea>
	</div>
	<button class="btn btn-primary" name="submit">Ubah</button>
</form>

<?php 
if (isset($_POST['submit'])) {
	$namafoto=$_FILES['foto']['name'];
	$lokasifoto = $_FILES['foto']['tmp_name'];
	if (!empty($lokasifoto)) {
		move_uploaded_file($lokasifoto, "../foto_produk/$namafoto");

		$namaruangan=$_POST['nama'];
		$stok=$_POST['stok'];
		$deskripsi=$_POST['deskripsi'];

		$conn->query("UPDATE ruangan SET nama_ruangan='$_POST[nama]',stok='$_POST[stok]',deskripsi_ruangan='$_POST[deskripsi]' WHERE id_ruangan='$_GET[id]'");
	}
	else{
		$conn->query("UPDATE ruangan SET nama_ruangan='$_POST[nama]',stok='$_POST[stok]',deskripsi_ruangan='$_POST[deskripsi]' WHERE id_ruangan='$_GET[id]'");
	}
	echo "<script>alert('Data Berhasil Diubah');</script>";
	echo "<script>location='index.php?halaman=ruangan';</script>";
}
?>