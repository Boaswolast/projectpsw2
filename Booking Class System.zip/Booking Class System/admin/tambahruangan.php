<?php include 'protect.php'; ?>
<h2>Tambah Ruangan</h2>

<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>ID Gedung (<i>**Buka tab Gedung untuk melihat ID Gedung</i>)</label>
		<input type="text" class="form-control" name="idgedung">
	</div>
	<div class="form-group">
		<label>Nama Ruangan</label>
		<input type="text" class="form-control" name="nama">
	</div>
	<div class="form-group">
		<label>Data</label>
		<input type="number" class="form-control" name="stok">
	</div>
	<div class="form-group">
		<label>Deskripsi</label>
		<textarea class="form-control" name="deskripsi" rows="5"></textarea>
	</div>
	<button class="btn btn-primary" name="submit">Simpan</button>
</form>
<?php if (isset($_POST['submit'])) {
	$idgedung = $_POST['idgedung'];
	$namafoto = $_FILES['foto']['name'];
	$lokasi= $_FILES['foto']['tmp_name'];
	move_uploaded_file($lokasi, "../foto_produk/".$namafoto);
	$nama = $_POST['nama'];
	$stok = $_POST['stok'];
	$deskripsi = $_POST['deskripsi'];
	$conn->query("INSERT INTO ruangan(nama_ruangan,stok,deskripsi_ruangan,id_gedung) 
		VALUES ('$nama','$stok','$deskripsi','$idgedung')");
	echo "<div class='alert alert-info'>Data Tersimpan</div>";
	echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=ruangan'>";
}?>
