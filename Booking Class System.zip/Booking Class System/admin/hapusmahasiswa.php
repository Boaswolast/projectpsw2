<?php 
	$query=$conn->query("SELECT * FROM mahasiswa WHERE id_mahasiswa='$_GET[id]'");
	$data= $query->fetch_assoc();

	$conn->query("DELETE FROM mahasiswa WHERE id_mahasiswa='$_GET[id]'");
	echo "<script>alert('Mahasiswa Berhasil Dihapus');</script>";
	echo "<script>location='index.php?halaman=mahasiswa';</script>";
?>