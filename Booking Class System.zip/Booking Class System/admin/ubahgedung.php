<?php include 'protect.php'; ?>
<h2>Ubah Gedung</h2>
<?php 
	$query=$conn->query("SELECT * FROM gedung WHERE id_gedung='$_GET[id]'");
	$data=$query->fetch_assoc();
?>
<form role="form" method="POST">
	<div class="form-group">
		<label>Nama Gedung</label>
		<input type="text" class="form-control" name="nama" value="<?php echo $data['nama_gedung']; ?>">
	</div>
	<div class="form-group">
		<label>Alamat</label>
		<input type="text" class="form-control" name="alamat" value="<?php echo $data['alamat_gedung']; ?>">
	</div>
	<button class="btn btn-primary" name="submit">Ubah</button>
</form>
<?php 
	if (isset($_POST['submit'])) {
		$query = $conn->query("UPDATE gedung SET nama_gedung='$_POST[nama]', alamat_gedung='$_POST[alamat]' WHERE id_gedung='$_GET[id]'");
		echo "<script>alert('Data Berhasil Diubah');</script>";
		echo "<script>location='index.php?halaman=gedung';</script>";
	}
?>