<?php 
	$query=$conn->query("SELECT * FROM ruangan WHERE id_ruangan='$_GET[id]'");
	$data= $query->fetch_assoc();

	$conn->query("DELETE FROM ruangan WHERE id_ruangan='$_GET[id]'");

	echo "<script>alert('ruangan Berhasil Dihapus');</script>";
	echo "<script>location='index.php?halaman=ruangan'</script>";
?> 