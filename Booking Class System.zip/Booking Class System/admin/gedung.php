<?php include 'protect.php'; ?>
<h2>Data Gedung</h2>

<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>No</th>
				<th>ID Gedung</th>
				<th>Nama Gedung</th>
				<th>Gedung Fakultas</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $no=1; ?>
			<?php $ambil=$conn->query("SELECT * FROM gedung"); ?>
			<?php while ($data=$ambil->fetch_assoc()) {
				?>
				<tr>
					<td><?php echo $no++ ?></td>
					<td><?php echo $data['id_gedung']; ?></td>
					<td><?php echo $data['nama_gedung']; ?></td>
					<td><?php echo $data['alamat_gedung']; ?></td>
					<td>	
						<a href="index.php?halaman=ubahgedung&id=<?php echo $data['id_gedung']; ?>" class="btn btn-warning">Ubah</a>
					</td>
				</tr>
				<?php
			} ?>
		</tbody>
	</table>	
</div>
<a href="index.php?halaman=tambahgedung" class="btn btn-primary">Tambah Gedung</a>