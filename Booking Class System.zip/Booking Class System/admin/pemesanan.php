<?php include 'protect.php'; ?>
<h2>History pemesanan</h2>

<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama Mahasiswa</th>
				<th>Tanggal</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php $no=1; ?>
			<?php $query=$conn->query("SELECT * FROM pemesanan JOIN mahasiswa ON pemesanan.id_mahasiswa=mahasiswa.id_mahasiswa") ?>
			<?php while ($data=$query->fetch_assoc()) {
				?>
				<tr>
					<td><?php echo $no++; ?></td>
					<td><?php echo $data['nama_mahasiswa']; ?></td>
					<td><?php echo $data['tanggal_pemesanan']; ?></td>
					<td>
						<a href="index.php?halaman=detail&id=<?php echo $data['id_pemesanan']; ?>" class="btn btn-info">Detail</a>
					</td>
				</tr>

				
				<?php
			} ?>
		</tbody>
		
	</table>	
</div>