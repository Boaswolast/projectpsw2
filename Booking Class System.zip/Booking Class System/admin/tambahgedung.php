<?php include 'protect.php'; ?>
<h2>Tambah Gedung</h2>

<form role="form" method="POST">
	<div class="form-group">
		<label>Nama Gedung</label>
		<input type="text" class="form-control" name="nama">
	</div>
	<div class="form-group">
		<label>Alamat</label>
		<input type="text" class="form-control" name="alamat">
	</div>
	<button class="btn btn-primary" name="submit">Simpan</button>
</form>
<?php 
	if (isset($_POST['submit'])) {
		$query=$conn->query("INSERT INTO gedung VALUES ('','$_POST[nama]','$_POST[alamat])");
		echo "<br><div class='alert alert-info'>Data Tersimpan</div>";
		echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=gedung'>";
	}
?>