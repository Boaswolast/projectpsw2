<?php include 'protect.php'; ?>
<h2>Detail pemesanan</h2>
<?php 
$query=$conn->query("SELECT * FROM pemesanan JOIN mahasiswa ON
	pemesanan.id_mahasiswa=mahasiswa.id_mahasiswa
	WHERE pemesanan.id_pemesanan='$_GET[id]'");
$detail=$query->fetch_assoc();
?>
<p><strong><?php echo $detail['nama_mahasiswa']; ?></strong><br></p>
<p>
	Nim: <?php echo $detail['nim']; ?><br>
	Kelas Mahasiswa: <?php echo $detail['kelas_mahasiswa']; ?>
</p>
<p>
	Tanggal : <?php echo $detail['tanggal_pemesanan']; ?><br>
</p>

<div class="table-responsive">	
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama Ruangan</th>
				<th>Pesanan</th>
			</tr>
		</thead>
		<tbody>
			<?php $no=1; ?>
			<?php $query=$conn->query("SELECT * FROM pemesanan_ruangan JOIN ruangan
				ON pemesanan_ruangan.id_ruangan=ruangan.id_ruangan
				WHERE pemesanan_ruangan.id_pemesanan='$_GET[id]'"); ?>
			<?php while ( $data=$query->fetch_assoc()) {
				?>
				<tr>
					<td><?php echo $no++; ?></td>
					<td><?php echo $data['nama_ruangan']; ?></td>
					<td><?php echo $data['jumlah'] ?></td>
				</tr>
				<?php
			} ?>
		</tbody>
	</table>
</div>