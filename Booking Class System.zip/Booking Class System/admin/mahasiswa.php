<?php include 'protect.php'; ?>
<h2>Mahasiswa</h2>

<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>Nim</th>
				<th>Kelas Mahasiswa</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php $no=1; ?>
			<?php $query=$conn->query("SELECT * FROM mahasiswa"); ?>
			<?php while ($data=$query->fetch_assoc()) {
				?>
				<tr>
					<td><?php echo $no++; ?></td>
					<td><?php echo $data['nama_mahasiswa']; ?></td>
					<td><?php echo $data['nim']; ?></td>
					<td><?php echo $data['kelas_mahasiswa']; ?></td>
					<td>
						<a href="index.php?halaman=hapusmahasiswa&id=<?php echo $data['id_mahasiswa']; ?>" class="btn btn-danger">Hapus</a>
					</td>
				</tr>
				<?php
			} ?>
		</tbody>
	</table>
</div>