<?php include 'protect.php'; ?>
<h2>Data Ruangan</h2>

<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>No</th>
				<th>Gedung</th>
				<th>Nama Ruangan</th>
				<th>Data</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $no=1; ?>
			<?php $ambil=$conn->query("SELECT * FROM ruangan JOIN gedung ON ruangan.id_gedung=gedung.id_gedung"); ?>
			<?php while ($data=$ambil->fetch_assoc()) {
				?>
				<tr>
					<td><?php echo $no++ ?></td>
					<td><?php echo $data['nama_gedung']; ?></td>
					<td><?php echo $data['nama_ruangan']; ?></td>
					<td><?php echo $data['stok']; ?></td>
					<td>
						<a href="index.php?halaman=hapusruangan&id=<?php echo $data['id_ruangan']; ?>" class="btn-danger btn">Hapus</a>
						<a href="index.php?halaman=ubahruangan&id=<?php echo $data['id_ruangan']; ?>" class="btn btn-warning">Ubah</a>
					</td>
				</tr>
				<?php
			} ?>
		</tbody>	
	</table>
</div>
<a href="index.php?halaman=tambahruangan" class="btn btn-primary">Tambah Ruangan</a>