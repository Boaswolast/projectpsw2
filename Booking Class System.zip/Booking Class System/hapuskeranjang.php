<?php 
session_start();
$id_ruangan=$_GET['id'];
unset($_SESSION["keranjang"][$id_ruangan]);

echo "<script>alert('Item terhapus dari booking');</script>";
echo "<script>location='cart.php';</script>";
?>