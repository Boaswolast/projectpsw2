<?php
session_start();
error_reporting(0);
?>

<center><h2>Nota Pemesanan #<?php echo $_GET['id']?></h2></center>
    
<table border="1" cellpadding="5">
  <tr>
    <th>No</th>
    <th>Ruangan</th>
    <th>Info Gedung</th>
    <th>Jumlah</th>
  </tr>
  <?php
  
  include "koneksi.php";
  
  
  $query = $conn->query("SELECT * FROM pemesanan_ruangan JOIN ruangan
    ON pemesanan_ruangan.id_ruangan=ruangan.id_ruangan JOIN gedung ON ruangan.id_gedung=gedung.id_gedung
    WHERE pemesanan_ruangan.id_pemesanan='$_GET[id]'");

  $no = 1; 
  while($data = $query->fetch_assoc()){ 
    ?>
    <tr>
      <td><?php echo $no++; ?></td>
      <td><?php echo $data['nama_ruangan']; ?></td>
      <td><?php echo $data['nama_gedung']; ?> (<?php echo $data['alamat_gedung']; ?>)</td>
      <td><?php echo $data['jumlah'] ?></td>
    </tr>
    <?php
  }
  ?>
  
  <?php
  ?>
</table>
<tfood>

<h4><b><i>Nb : Silahkan hubungi CP gedung untuk memesan ruangan</i></b></h4>

<div class="col-sm-4">
                                <h3><i class="fa fa-user"></i> Pelanggan</h3>
                                <p><strong><?php echo $_SESSION['login']['nama_mahasiswa']; ?></strong><br>
                                    <?php echo $_SESSION['login']['nim']; ?><br>
                                    <?php echo $_SESSION['login']['kelas_mahasiswa']; ?>
                                </p>
                            </div>

<div class="col-sm-4">
<script>
  window.print()
</script>
